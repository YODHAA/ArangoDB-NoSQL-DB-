'use strict';

module.context.use('/mytest', require('./routes/mytest'), 'mytest');
